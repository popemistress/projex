import baseConfig from "@kan/eslint-config/base";

export default [...baseConfig];