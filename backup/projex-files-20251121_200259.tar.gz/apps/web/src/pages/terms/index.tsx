import TermsView from "~/views/terms";

export default function Terms() {
  return <TermsView />;
}
