import LoginView from "~/views/auth/login";

export default function LoginPage() {
  return <LoginView />;
}
