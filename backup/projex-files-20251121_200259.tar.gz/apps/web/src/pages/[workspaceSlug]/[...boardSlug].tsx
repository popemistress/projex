import PublicBoardView from "~/views/public/board";

export default function PublicBoardsPage() {
  return <PublicBoardView />;
}
