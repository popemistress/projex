import PublicBoardsView from "~/views/public/boards";

export default function PublicBoardsPage() {
  return <PublicBoardsView />;
}
