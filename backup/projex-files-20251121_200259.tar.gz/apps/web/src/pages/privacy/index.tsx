import PrivacyView from "~/views/privacy";

export default function Privacy() {
  return <PrivacyView />;
}
