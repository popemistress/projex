import OSSFriendsView from "~/views/oss-friends";

export default function OSSFriends() {
  return <OSSFriendsView />;
}
