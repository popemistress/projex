import InviteView from "~/views/invite";

export default function InvitePage() {
  return <InviteView />;
}
