import SignupView from "~/views/auth/signup";

export default function SignupPage() {
  return <SignupView />;
}
