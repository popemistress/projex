import PricingView from "~/views/pricing";

export default function Pricing() {
  return <PricingView />;
}
