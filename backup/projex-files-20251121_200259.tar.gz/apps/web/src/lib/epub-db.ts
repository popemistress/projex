// Simple in-memory storage for EPUB reading progress
// This could be replaced with a proper database implementation later

interface EpubProgress {
  documentId: string;
  currentLocation: string;
  progress: number;
  lastRead: Date;
}

class EpubDatabase {
  private storage = new Map<string, EpubProgress>();

  saveProgress(documentId: string, location: string, progress: number) {
    this.storage.set(documentId, {
      documentId,
      currentLocation: location,
      progress,
      lastRead: new Date(),
    });
  }

  getProgress(documentId: string): EpubProgress | null {
    return this.storage.get(documentId) ?? null;
  }

  getAllProgress(): EpubProgress[] {
    return Array.from(this.storage.values());
  }

  deleteProgress(documentId: string) {
    this.storage.delete(documentId);
  }
}

export const epubDB = new EpubDatabase();
