#!/bin/bash

# Complete Backup Script for Kan Project
# Creates backup of project files and database

set -e  # Exit on any error

BACKUP_DIR="/home/yamz/sites/projex/backup"
PROJECT_DIR="/home/yamz/sites/projex"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

echo "🚀 Starting complete backup process..."
echo "📅 Timestamp: $TIMESTAMP"
echo "📁 Backup directory: $BACKUP_DIR"

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# 1. Create project files backup (excluding node_modules, .next, logs, and backup folder itself)
echo "📦 Creating project files backup..."
cd "$PROJECT_DIR"
tar --exclude='node_modules' \
    --exclude='.next' \
    --exclude='logs' \
    --exclude='backup' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='dist' \
    --exclude='.turbo' \
    --exclude='.cache' \
    -czf "$BACKUP_DIR/projex-files-$TIMESTAMP.tar.gz" .

echo "✅ Project files backup created: projex-files-$TIMESTAMP.tar.gz"

# 2. Create database backup
echo "🗄️ Creating database backup..."
if [ -n "$POSTGRES_URL" ]; then
    # Extract database name from POSTGRES_URL for the backup filename
    DB_NAME=$(echo "$POSTGRES_URL" | sed 's/.*\/\([^?]*\).*/\1/')
    
    # Create database dump
    pg_dump "$POSTGRES_URL" > "$BACKUP_DIR/database-$DB_NAME-$TIMESTAMP.sql"
    
    # Compress the database dump
    gzip "$BACKUP_DIR/database-$DB_NAME-$TIMESTAMP.sql"
    
    echo "✅ Database backup created: database-$DB_NAME-$TIMESTAMP.sql.gz"
else
    echo "⚠️  POSTGRES_URL not found in environment, skipping database backup"
fi

# 3. Create environment backup (without sensitive data)
echo "🔧 Creating environment configuration backup..."
if [ -f "$PROJECT_DIR/.env" ]; then
    # Create sanitized env backup (remove sensitive values)
    sed 's/=.*/=***REDACTED***/' "$PROJECT_DIR/.env" > "$BACKUP_DIR/env-template-$TIMESTAMP.txt"
    echo "✅ Environment template backup created: env-template-$TIMESTAMP.txt"
fi

# Copy .env.example as reference
if [ -f "$PROJECT_DIR/.env.example" ]; then
    cp "$PROJECT_DIR/.env.example" "$BACKUP_DIR/env-example-$TIMESTAMP.txt"
    echo "✅ Environment example backup created: env-example-$TIMESTAMP.txt"
fi

# 4. Create PM2 ecosystem backup
echo "⚙️ Creating PM2 configuration backup..."
if [ -f "$PROJECT_DIR/ecosystem.config.js" ]; then
    cp "$PROJECT_DIR/ecosystem.config.js" "$BACKUP_DIR/ecosystem-config-$TIMESTAMP.js"
    echo "✅ PM2 ecosystem backup created: ecosystem-config-$TIMESTAMP.js"
fi

# 5. Create Nginx configuration backup
echo "🌐 Creating Nginx configuration backup..."
if [ -f "$PROJECT_DIR/nginx-projex.conf" ]; then
    cp "$PROJECT_DIR/nginx-projex.conf" "$BACKUP_DIR/nginx-config-$TIMESTAMP.conf"
    echo "✅ Nginx configuration backup created: nginx-config-$TIMESTAMP.conf"
fi

# 6. Create package.json files backup for dependency tracking
echo "📋 Creating dependency manifests backup..."
find "$PROJECT_DIR" -name "package.json" -not -path "*/node_modules/*" -not -path "*/backup/*" | \
    tar -czf "$BACKUP_DIR/package-manifests-$TIMESTAMP.tar.gz" -T -
echo "✅ Package manifests backup created: package-manifests-$TIMESTAMP.tar.gz"

# 7. Create backup manifest
echo "📝 Creating backup manifest..."
cat > "$BACKUP_DIR/backup-manifest-$TIMESTAMP.txt" << EOF
# Kan Project Backup Manifest
# Created: $(date)
# Backup ID: $TIMESTAMP

## Backup Contents:
- projex-files-$TIMESTAMP.tar.gz          # Complete project source code
- database-*-$TIMESTAMP.sql.gz            # PostgreSQL database dump
- env-template-$TIMESTAMP.txt             # Environment variables template
- env-example-$TIMESTAMP.txt              # Environment example file
- ecosystem-config-$TIMESTAMP.js          # PM2 configuration
- nginx-config-$TIMESTAMP.conf            # Nginx configuration
- package-manifests-$TIMESTAMP.tar.gz     # All package.json files
- backup-manifest-$TIMESTAMP.txt          # This manifest file

## Restore Instructions:
1. Extract project files: tar -xzf projex-files-$TIMESTAMP.tar.gz
2. Restore database: gunzip -c database-*-$TIMESTAMP.sql.gz | psql \$POSTGRES_URL
3. Configure environment: cp env-example-$TIMESTAMP.txt .env (then edit)
4. Install dependencies: pnpm install
5. Build project: pnpm build
6. Start services: pm2 start ecosystem-config-$TIMESTAMP.js

## System Info:
- Hostname: $(hostname)
- User: $(whoami)
- Node Version: $(node --version 2>/dev/null || echo "Not available")
- PM2 Version: $(pm2 --version 2>/dev/null || echo "Not available")
- PostgreSQL Version: $(psql --version 2>/dev/null || echo "Not available")

## Project Status at Backup:
- Production server running: $(pm2 status 2>/dev/null | grep -q "kan-projex.*online" && echo "Yes" || echo "No")
- Last build: $(stat -c %y "$PROJECT_DIR/apps/web/.next" 2>/dev/null || echo "Not available")
EOF

echo "✅ Backup manifest created: backup-manifest-$TIMESTAMP.txt"

# 8. Display backup summary
echo ""
echo "🎉 Backup completed successfully!"
echo "📊 Backup Summary:"
echo "=================="
ls -lh "$BACKUP_DIR"/*$TIMESTAMP* | while read line; do
    echo "  $line"
done

echo ""
echo "💾 Total backup size:"
du -sh "$BACKUP_DIR"/*$TIMESTAMP* | awk '{sum+=$1} END {print "  " sum " (approximate)"}'

echo ""
echo "📍 Backup location: $BACKUP_DIR"
echo "🔖 Backup ID: $TIMESTAMP"
echo ""
echo "✨ Backup process completed!"
