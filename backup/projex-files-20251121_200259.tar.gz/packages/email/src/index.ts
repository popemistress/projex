export const name = "email";

export { sendEmail } from "./sendEmail";
export { cloudMailerClient } from "./cloudMailerClient";
