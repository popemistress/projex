import Mail from '../../emails/magic-link.tsx';
export default Mail;
