const languageMap = {
  jsx: 'React',
  markup: 'HTML',
  markdown: 'Plain Text',
};

export default languageMap;
